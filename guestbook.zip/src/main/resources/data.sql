-- insert into post(name, writedate, content) values ('정환열', '2019-06-28 00:00:00', '결혼 축하합니다');
select now();